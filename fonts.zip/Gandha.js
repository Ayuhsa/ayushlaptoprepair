< !DOCTYPE html >
    <
    html >

    <
    head >
    <!-- Basic -->
    <
    meta charset = "utf-8" / >
    <
    meta http - equiv = "X-UA-Compatible"
content = "IE=edge" / >
    <!-- Mobile Metas -->
    <
    meta name = "viewport"
content = "width=device-width, initial-scale=1, shrink-to-fit=no" / >
    <!-- Site Metas -->
    <
    link href = "/dist/output.css"
rel = "stylesheet" >
    <
    link rel = "icon"
href = "images/favicon.png"
type = "image/gif" / >
    <
    meta name = "keywords"
content = "" / >
    <
    meta name = "description"
content = "" / >
    <
    meta name = "author"
content = "" / >

    <
    title > AYUSH LAPTOP REPAIR < /title> <
    script src = "js/script.js" > < /script>
    <!-- slider stylesheet -->
    <
    link rel = "stylesheet"
type = "text/css"
href = "https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" / >
    <!-- bootstrap core css -->
    <
    link rel = "stylesheet"
type = "text/css"
href = "css/bootstrap.css" / >
    <!-- fonts style -->
    <
    link href = "https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap"
rel = "stylesheet" >
    <!-- range slider -->
    <!-- font awesome style -->
    <
    link href = "css/font-awesome.min.css"
rel = "stylesheet" / >
    <
    script src = "https://cdn.tailwindcss.com?plugins=forms,typography,aspect-ratio,line-clamp" > < /script>

<!-- Custom styles for this template -->
<
link href = "css/style.css"
rel = "stylesheet" / >
    <!-- responsive style -->
    <
    link href = "css/responsive.css"
rel = "stylesheet" / >

    <
    script src = "https://cdn.tailwindcss.com" > < /script> <
    link rel = "stylesheet"
href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"
integrity = "sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ=="
crossorigin = "anonymous"
referrerpolicy = "no-referrer" /
    >
    <
    /head>

<
body >

    <
    div class = "hero_area" >
    <!-- header section strats -->
    <
    header class = "header_section" >
    <
    div class = "header_top" >
    <
    div class = "container-fluid" >
    <
    div class = "top_nav_container" >
    <
    a class = "navbar-brand d-none d-lg-flex"
href = "index.html" >
    <
    span >
    AYUSH < strong style = "color:#007bff " > LAPTOP < /strong> REPAIR <
    /span> <
    /a> <
    div class = "contact_nav" >
    <
    a href = "" >
    <
    i class = "fa fa-phone"
aria - hidden = "true" > < /i> <
    span >
    Call: +91 9999608715 <
    /span> <
    /a> <
    a href = "" >
    <
    i class = "fa-brands fa-whatsapp" > < /i> <
    span >
    Whatsapp: 7835975689 <
    /span> <
    /a>

<
a href = "" >
    <
    i class = "fa fa-envelope"
aria - hidden = "true" > < /i> <
    span >
    Email: demo @gmail.com <
    /span> <
    /a> <
    /div> <
    /div> <
    /div> <
    /div> <
    div class = "header_bottom" >
    <
    div class = "container-fluid" >
    <
    nav class = "navbar navbar-expand-lg custom_nav-container " >
    <
    a class = "navbar-brand d-lg-none"
href = "index.html" >
    <
    span >
    Tracork <
    /span> <
    /a>

<
button class = "navbar-toggler"
type = "button"
data - toggle = "collapse"
data - target = "#navbarSupportedContent"
aria - controls = "navbarSupportedContent"
aria - expanded = "false"
aria - label = "Toggle navigation" >
    <
    span class = "" > < /span> <
    /button>

<
div class = "collapse navbar-collapse"
id = "navbarSupportedContent" >
    <
    ul class = "navbar-nav" >
    <
    li class = "nav-item active" >
    <
    a class = "nav-link pl-lg-0"
href = "index.html" > Home < span class = "sr-only" > (current) < /span></a >
    <
    /li> <
    li class = "nav-item" >
    <
    a class = "nav-link"
href = "service.html" > Services < /a> <
    /li> <
    li class = "nav-item" >
    <
    a class = "nav-link"
href = "about.html" > About < /a> <
    /li> <
    li class = "nav-item" >
    <
    a class = "nav-link"
href = "why.html" > Why Us < /a> <
    /li> <
    li class = "nav-item" >
    <
    a class = "nav-link"
href = "contact.html" > Contact Us < /a> <
    /li> <
    /ul> <
    from class = "search_form" >
    <
    input type = "text"
class = "form-control"
placeholder = "Search here..." >
    <
    button class = ""
type = "submit" >
    <
    i class = "fa fa-search"
aria - hidden = "true" > < /i> <
    /button> <
    /from> <
    /div> <
    /nav> <
    /div> <
    /div> <
    /header>
    <!-- end header section -->
    <!-- slider section -->
    <
    section class = "slider_section " >
    <
    div class = "slider-bg" >
    <
    img src = "images/slider-bg.jpg"
alt = "" >
    <
    /div> <
    div id = "customCarousel1"
class = "carousel slide"
data - ride = "carousel" >
    <
    div class = "carousel-inner" >
    <
    div class = "carousel-item active" >
    <
    div class = "container " >
    <
    div class = "row" >
    <
    div class = "col-lg-6" >
    <
    div class = "detail-box" >
    <
    h1 >
    Computer problem ? < br > We will fix your computer. <
    /h1>


<
p style = "  letter-spacing: 2px;" >
    We offer comprehensive computer repair and services to address all your device needs.Our goal is to provide exceptional service and ensure that your computer runs smoothly, allowing you to focus on your work and activities without any interruption. <
    /p> <
    /p> <
    a href = "" >
    Read More <
    /a> <
    /div> <
    /div> <
    /div> <
    /div> <
    /div> <
    div class = "carousel-item" >
    <
    div class = "container " >
    <
    div class = "row" >
    <
    div class = "col-lg-6" >
    <
    div class = "detail-box" >
    <
    h1 >
    Computer problem ? < br > We will fix your computer. <
    /h1> <
    p >
    Lorem ipsum dolor sit amet, consectetur adipisicing elit.Iste quam velit saepe dolorem deserunt quo quidem ad optio.Our goal is to provide exceptional service and ensure that your computer runs smoothly, allowing you to focus on your work and activities
without any interruption. <
    /p> <
    a href = "" >
    Read More <
    /a> <
    /div> <
    /div> <
    /div> <
    /div> <
    /div> <
    div class = "carousel-item" >
    <
    div class = "container " >
    <
    div class = "row" >
    <
    div class = "col-lg-6" >
    <
    div class = "detail-box" >
    <
    h1 >
    Computer problem ? < br > We will fix your computer <
    /h1> <
    p >
    Lorem ipsum dolor sit amet, consectetur adipisicing elit.Iste quam velit saepe dolorem deserunt quo quidem ad optio. <
    /p> <
    a href = "" >
    Read More <
    /a> <
    /div> <
    /div> <
    /div> <
    /div> <
    /div> <
    /div> <
    div class = "carousel_btn_box" >
    <
    a class = "carousel-control-prev"
href = "#customCarousel1"
role = "button"
data - slide = "prev" >
    <
    i class = "fa fa-angle-left"
aria - hidden = "true" > < /i> <
    span class = "sr-only" > Previous < /span> <
    /a> <
    a class = "carousel-control-next"
href = "#customCarousel1"
role = "button"
data - slide = "next" >
    <
    i class = "fa fa-angle-right"
aria - hidden = "true" > < /i> <
    span class = "sr-only" > Next < /span> <
    /a> <
    /div> <
    /div> <
    /section>
    <!-- end slider section -->
    <
    /div>


<!-- service section -->
<
section class = "service_section layout_padding"
style = "background-color: white;" >
    <
    div class = "service_container"
style = "background-color: white;" >
    <
    div class = "container " >
    <
    div class = "heading_container heading_center" >
    <
    h2 >
    Our < span > Services < /span> <
    /h2> <
    p >
    Our computer and laptop services include a wide range of solutions to ensure that your devices run smoothly.From repairs to upgrades, virus removal to data backup, we are committed to providing efficient and reliable services to meet your technology
needs. <
    /p>




<
/p1> <
/div> <
div class = "row" >
    <
    div class = "col-md-6 " >
    <
    div class = "box " >
    <
    div class = "img-box" >
    <
    img src = "images/s1.png"
alt = "" >
    <
    /div> <
    div class = "detail-box" >
    <
    h5 >
    Computer Repair <
    /h5> <
    p >
    Computer repair services are essential
for individuals and businesses to ensure that their devices operate smoothly and efficiently.


<
span id = "dots" > ... < /span><span id="more" style="display: none;">  Whether it's a hardware issue such as a broken screen or a software problem such as a virus, prompt and reliable repairs
can save time, money, and frustration.Repairing a computer involves identifying the problem and determining the appropriate solution, which may involve replacing a component, running diagnostics or malware scans, or
updating software.Seeking the help of a professional computer repair technician can ensure that the job is done correctly and efficiently, allowing you to get back to using your device without any issues. < /span>





<
/p> <
button onclick = "myFunction()"
id = "myBtn"
style = "width: 200px; background-color: black; color:white; font-size: 20px;" > Read more < /button>
    <!-- <a href="">

<
/a> -->

<
/div> <
/div> <
/div>
<!-- <div class="col-md-6 ">
<
div class = "box " >
    <
    div class = "img-box" >
    <
    img src = "images/s2.png"
alt = "" >
    <
    /div> <
    div class = "detail-box" >
    <
    h5 >
    Hardware Replacement <
    /h5> <
    p >
    Hardware replacement is a common solution
for repairing a computer when a component is damaged or malfunctioning...

<
span id = "dotss" > ... < /span><span id="mores" style="display: none;">  Whether it's a hardware issue such as a broken screen or a software problem such as a virus, prompt and reliable repairs
can save time, money, and frustration.Repairing a computer involves identifying the problem and determining the appropriate solution, which may involve replacing a component, running diagnostics or malware scans, or
updating software.Seeking the help of a professional computer repair technician can ensure that the job is done correctly and efficiently, allowing you to get back to using your device without any issues. < /span> <
    /p> <
    button onclick = "myFunctions()"
id = "myBtns"
style = "width: 200px; background-color: black; color:white; font-size: 20px;" > Read more < /button>

<
/div> <
/div> <
/div> -->






<
div class = "col-md-6 " >
    <
    div class = "box " >
    <
    div class = "img-box" >
    <
    img src = "images/s1.png"
alt = "" >
    <
    /div> <
    div class = "detail-box" >
    <
    h5 >
    Hardware Replacement <
    /h5> <
    p >
    Hardware replacement is a common solution
for repairing a computer when a component is damaged or malfunctioning...

<
span id = "dotss" > ... < /span><span id="mores" style="display: none;">  Whether it's a hardware issue such as a broken screen or a software problem such as a virus, prompt and reliable repairs
can save time, money, and frustration.Repairing a computer involves identifying the problem and determining the appropriate solution, which may involve replacing a component, running diagnostics or malware scans, or
updating software.Seeking the help of a professional computer repair technician can ensure that the job is done correctly and efficiently, allowing you to get back to using your device without any issues. < /span> <
    /p> <
    button onclick = "myFunctions()"
id = "myBtns"
style = "width: 200px; background-color: black; color:white; font-size: 20px;" > Read more < /button>

<
/div> <
/div> <
/div>












<!-- <div class="detail-box">
<
h5 >
    Data Recovery <
    /h5> <
    p >
    <
    p >
    dsaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa..

<
span id = "dotsss" > ... < /span><span id="moress" style="display: none;">     Data recovery is a crucial service for individuals and businesses who have lost valuable information due to a computer malfunction, virus, or accidental deletion. Data recovery involves using specialized tools and techniques to recover lost, deleted,
or corrupted files from a computer or storage device.The process can be complex and time - consuming, and it is important to seek the help of a professional data recovery service provider who has the expertise and resources
necessary to ensure a successful recovery.Data recovery can save valuable time, money, and resources by preventing the need
for recreating lost data or starting from scratch. < /span> <
    /p> <
    /p> <
    button onclick = "myFunctionss()"
id = "myBtnss"
style = "width: 200px; background-color: black; color:white; font-size: 20px;" > Read more < /button> <
    /div> -->










<
div class = "col-md-6 " >
    <
    div class = "box " >
    <
    div class = "img-box" >
    <
    img src = "images/s3.png"
alt = "" >
    <
    /div> <
    div class = "detail-box" >
    <
    h5 >
    Data Recovery <
    /h5> <
    p >
    <
    p >
    To recover data from a damaged database, you can either use database recovery software or seek the services of a professional data recovery company <
    span id = "dotsss" > ... < /span><span id="moress" style="display: none;">     
Data recovery is a crucial service
for individuals and businesses who have lost valuable information due to a computer malfunction, virus, or accidental deletion.Data recovery involves using specialized tools and techniques to recover lost, deleted,
    or corrupted files from a computer or storage device.The process can be complex and time - consuming, and it is important to seek the help of a professional data recovery service provider who has the expertise and resources
necessary to ensure a successful recovery.Data recovery can save valuable time, money, and resources by preventing the need
for recreating lost data or starting from scratch. < /span> <
    /p>

<
ul class = ""
style = "color:black;   list-style-type: square;" >
    <
    li > Data recovery software: There are many data recovery software programs available that can help repair damaged databases.These tools scan the damaged database
for errors and attempt to repair them automatically.
However, their success rate depends on the extent of the damage, and they may not be able to recover all of the lost data. < /li> <
    /ul>

<!-- <ul class="" style="color:black;   list-style-type: square;">
<
li > Coffee < /li> <
    li > Tea < /li> <
    li > Milk < /li> <
    /ul> --> <
    /p> <
    button onclick = "myFunctionss()"
id = "myBtnss"
style = "width: 200px; background-color: black; color:white; font-size: 20px;" > Read more < /button> <
    /div> <
    /div> <
    /div>













<
div class = "col-md-6 " >
    <
    div class = "box " >
    <
    div class = "img-box" >
    <
    img src = "images/s4.png"
alt = "" >
    <
    /div> <
    div class = "detail-box" >
    <
    h5 >
    Software Update <
    /h5> <
    p >
    Software updates are essential
for keeping your computer or laptop running smoothly and securely.Outdated software can lead to compatibility issues, security vulnerabilities, and performance problems.Updating your software can improve the device 's stability,
functionality, and security, as well as fix bugs and errors.However, updating software can sometimes cause compatibility issues or software malfunctions.In such cases, seeking the help of a professional computer and
laptop repair service provider can help resolve the issue and ensure that your device continues to operate smoothly.A professional technician can also ensure that your software updates are done correctly and safely. <
    /p> <
    button onclick = "myFunctions()"
id = "myBtns"
style = "width: 200px; background-color: black; color:white; font-size: 20px;" > Read more < /button> <
    /div> <
    /div> <
    /div>




<
div class = "col-md-6 " >
    <
    div class = "box " >
    <
    div class = "img-box" >
    <
    img src = "images/s4.png"
alt = "" >
    <
    /div> <
    div class = "detail-box" >
    <
    h5 >
    Laptop repair <
    /h5> <
    p >
    Laptop repair services are essential
for individuals and businesses who rely on their laptops
for work or personal use.Laptops are susceptible to a range of issues, including broken screens, malfunctioning keyboards, and battery problems.Software - related
issues such as viruses or slow performance can also impact the device 's functionality. Laptop repair services include repairing or replacing damaged components, resolving software issues, and performing maintenance
to ensure that the device operates smoothly.Seeking the help of a professional laptop repair technician can save time, money, and frustration by ensuring that the repair is done correctly and efficiently.A professional
technician can also provide recommendations
for maintenance and upgrades to improve the device 's performance and extend its lifespan.


<
/p>

<
p1 >
    <
    ul >
    <
    li > Laptop keyboard repair or replacement, < /li> <
    li > Laptop battery repair or replacement, < /li> <
    li > Laptop adapter repair or replacement, < /li> <
    li > Laptop Booting problem, < /li> <
    li > If any Problem in recovering data from the hard disk drive, < /li> <
    li > Increasing Hard disk capacity, < /li> <
    li > Installation new firewall protection system, < /li> <
    li > Laptop Hinges Repair or Replacement, < /li> <
    li > Laptop LCD panel replacement or repair work, < /li> <
    li > Laptop Motherboard Repair or replacement, < /li> <
    li > Laptop Optical Drive repair issues, < /li> <
    li > Installing operating system, < /li> <
    li > Removing password in
    case you forgotten it, < /li> <
    li > Upgrading size of the Random access Memory, and much more. < /li> <
    /ul> <
    /p1> <
    button onclick = "myFunctions()"
id = "myBtns"
style = "width: 200px; background-color: black; color:white; font-size: 20px;" > Read more < /button> <
    /div> <
    /div> <
    /div>








<
div class = "col-md-6 " >
    <
    div class = "box " >
    <
    div class = "img-box" >
    <
    img src = "images/s4.png"
alt = "" >
    <
    /div> <
    div class = "detail-box" >
    <
    h5 >
    Macbook repair <
    /h5> <
    p >
    MacBook repair services are essential
for resolving a range of issues that can impact the device 's functionality. Some of the common causes of MacBook problems include hardware issues such as broken screens, malfunctioning keyboards, and battery problems.
Software - related issues such as viruses, slow performance, and software malfunctions can also impact the device 's functionality. Other causes of MacBook problems may include accidental damage, liquid spills, or physical
trauma.MacBook repair services include diagnosing the cause of the problem and determining the appropriate repair solution, which may involve replacing a component, running diagnostics or malware scans, or updating
software.Seeking the help of a professional MacBook repair service provider can ensure that the repair is done efficiently and correctly, saving time, money, and frustration.


<
/p>

<
p1 >
    <
    ul >
    <
    li > Hardware issues such as a broken screen, malfunctioning keyboard, or battery problems. < /li> <
    li > Software - related issues such as viruses, slow performance, and software malfunctions. < /li> <
    li > Accidental damage, such as dropping or spilling liquid on the device. < /li> <
    li > Overheating due to a malfunctioning cooling system or accumulation of dust. < /li> <
    li > If any Problem in recovering data from the hard disk drive, < /li> <
    li > Outdated software or operating system causing compatibility issues. < /li> <
    li > Power issues such as a dead battery or faulty charging system. < /li>
    <!-- <li>Laptop Hinges Repair or Replacement,</li>
    <
    li > Laptop LCD panel replacement or repair work, < /li> <
    li > Laptop Motherboard Repair or replacement, < /li> <
    li > Laptop Optical Drive repair issues, < /li> <
    li > Installing operating system, < /li> <
    li > Removing password in
    case you forgotten it, < /li> <
    li > Upgrading size of the Random access Memory, and much more. < /li> --> <
    /ul> <
    /p1> <
    button onclick = "myFunctions()"
id = "myBtns"
style = "width: 200px; background-color: black; color:white; font-size: 20px;" > Read more < /button> <
    /div> <
    /div> <
    /div>









<
div class = "col-md-6 " >
    <
    div class = "box " >
    <
    div class = "img-box" >
    <
    img src = "images/s4.png"
alt = "" >
    <
    /div> <
    div class = "detail-box" >
    <
    h5 >
    Camera repair <
    /h5> <
    p >
    A camera is a valuable device that allows us to capture important moments, memories, and events.However, just like any other piece of technology, a camera may need repair from time to time
for various reasons.


<
/p> <
p1 > One of the most common reasons
for camera repair is physical damage.Cameras can be dropped, bumped, or knocked around, causing damage to the lens, shutter, or other components.This can result in blurry or distorted images,
    or even render the camera unusable. < /p1> <
    p2 > Another reason
for camera repair is electronic or software issues.Cameras can experience glitches or malfunctions that can cause them to freeze, crash, or fail to turn on.This can be caused by various factors, such as
outdated firmware or a malfunctioning battery. < /p2> <
    p3 > Regular maintenance and cleaning are also important to keep a camera in good working condition.Dust and debris can accumulate on the lens or inside the camera body, affecting image quality and potentially causing damage
over time. < /p3> <
    p4 > In summary, we need to repair our cameras to ensure that they
continue to
function properly and produce high - quality images.By repairing any physical or electronic issues, as well as maintaining the camera with regular
cleaning and maintenance, we can prolong the lifespan of our cameras and
continue to capture important moments
for years to come. < /p4>

<
p1 >
    <
    ul >
    <
    li > Hardware issues such as a broken screen, malfunctioning keyboard, or battery problems. < /li> <
    li > Software - related issues such as viruses, slow performance, and software malfunctions. < /li> <
    li > Accidental damage, such as dropping or spilling liquid on the device. < /li> <
    li > Overheating due to a malfunctioning cooling system or accumulation of dust. < /li> <
    li > If any Problem in recovering data from the hard disk drive, < /li> <
    li > Outdated software or operating system causing compatibility issues. < /li> <
    li > Power issues such as a dead battery or faulty charging system. < /li>
    <!-- <li>Laptop Hinges Repair or Replacement,</li>
    <
    li > Laptop LCD panel replacement or repair work, < /li> <
    li > Laptop Motherboard Repair or replacement, < /li> <
    li > Laptop Optical Drive repair issues, < /li> <
    li > Installing operating system, < /li> <
    li > Removing password in
    case you forgotten it, < /li> <
    li > Upgrading size of the Random access Memory, and much more. < /li> --> <
    /ul> <
    /p1> <
    button onclick = "myFunctions()"
id = "myBtns"
style = "width: 200px; background-color: black; color:white; font-size: 20px;" > Read more < /button> <
    /div> <
    /div> <
    /div>














<
div class = "col-md-6 " >
    <
    div class = "box " >
    <
    div class = "img-box" >
    <
    img src = "images/s4.png"
alt = "" >
    <
    /div> <
    div class = "detail-box" >
    <
    h5 >
    Mobile repair <
    /h5> <
    p >
    Mobile phones have become an essential part of our lives and we rely heavily on them
for communication, entertainment, and information.However, these devices are prone to damage and malfunctions, which can cause a great deal of inconvenience.In such
situations, mobile repair services come to the rescue.Skilled technicians are able to diagnose and fix a range of problems, from cracked screens to software issues, quickly and efficiently.They use specialized tools
and techniques to carefully disassemble and reassemble the device, replacing faulty components and ensuring that it functions properly.With mobile repair services readily available, we can
continue to enjoy the benefits
of our devices without having to replace them unnecessarily.


<
/p>

<
ul >
    <
    li > Physical damage: Mobile phones are often dropped, bumped or knocked, which can result in cracked screens, broken buttons, or other physical damage. < /li> <
    li > Software issues: Mobile phones rely heavily on software, which can sometimes become corrupted or outdated, leading to performance issues, freezing or crashing. < /li> <
    li > Battery problems: Batteries can degrade over time, leading to shorter battery life or even failure. < /li> <
    li > Overheating: Overuse or exposure to high temperatures can cause a mobile phone to overheat, potentially causing damage to its internal components. < /li> <
    li > Water damage: Mobile phones are particularly vulnerable to water damage, which can occur
if they are dropped in water, exposed to high humidity or condensation. < /li>

<
/ul> <
/p1> <
button onclick = "myFunctions()"
id = "myBtns"
style = "width: 200px; background-color: black; color:white; font-size: 20px;" > Read more < /button> <
    /div> <
    /div> <
    /div> <
    /div> <
    div class = "btn-box" >
    <
    a href = "" >
    See All <
    /a> <
    /div> <
    /div> <
    /div> <
    /section>

<!-- end service section -->

<!-- about section -->

<
section class = "about_section"
style = "background-color: white;" >
    <
    div class = "container " >
    <
    div class = "row" >
    <
    div class = "col-md-6" >
    <
    div class = "detail-box" >
    <
    div class = "heading_container" >
    <
    h2 >
    We Provide Best Service <
    /h2> <
    /div> <
    p >
    <
    ul >
    <
    li >
    AYUSH LAPTOP REPAIR: This service offers repairs
for a wide range of devices, including computers, laptops, cameras, and mobile phones.They have a team of skilled technicians who can diagnose and fix issues quickly and efficiently. <
    /li>

<
li >
    AYUSH LAPTOP REPAIR: AYUSH LAPTOP REPAIR offers repairs
for a variety of devices, including smartphones, laptops, tablets, and gaming consoles.They offer a 90 - day warranty on their repairs and have over 100 locations across Dawarka. <
    /li>

<
li >
    CPR Cell Phone Repair: This service specializes in mobile phone and tablet repair, but also offers repairs
for computers and other electronics.They have over 100 locations worldwide and offer a limited lifetime warranty on their repairs. <
    /li>

<
li >
    Camera Repair: This is a specialized service that offers repair services
for high - end cameras, lenses, and other photography equipment.They have a team of highly skilled technicians and offer quick turnaround times on repairs. <
    /li> <
    /ul>

<
/p> <
a href = "" >
    Read More <
    /a> <
    /div> <
    /div> <
    div class = "col-md-6" >
    <
    div class = "img-box" >
    <
    img src = "images/about-img.jpg"
alt = "" >
    <
    /div> <
    /div> <
    /div> <
    /div> <
    /section>

<!-- end about section -->

<!-- why us section -->

<
section class = "why_us_section layout_padding"
style = "background-color: white;" >
    <
    div class = "container" >
    <
    div class = "heading_container heading_center" >
    <
    h2 >
    Why Choose Us <
    /h2> <
    /div> <
    div class = "row" >
    <
    div class = "col-md-4" >
    <
    div class = "box " >
    <
    div class = "img-box" >
    <
    img src = "images/w1.png"
alt = "" >
    <
    /div> <
    div class = "detail-box" >
    <
    h5 >
    Free Diagnostics <
    /h5> <
    p >
    variations of passages of Lorem Ipsum available <
    /p> <
    /div> <
    /div> <
    /div> <
    div class = "col-md-4" >
    <
    div class = "box " >
    <
    div class = "img-box" >
    <
    img src = "images/w2.png"
alt = "" >
    <
    /div> <
    div class = "detail-box" >
    <
    h5 >
    Quick Repair Process <
    /h5> <
    p >
    variations of passages of Lorem Ipsum available <
    /p> <
    /div> <
    /div> <
    /div> <
    div class = "col-md-4" >
    <
    div class = "box " >
    <
    div class = "img-box" >
    <
    img src = "images/w3.png"
alt = "" >
    <
    /div> <
    div class = "detail-box" >
    <
    h5 >
    Low Price Guarantee <
    /h5> <
    p >
    variations of passages of Lorem Ipsum available <
    /p> <
    /div> <
    /div> <
    /div> <
    /div> <
    /div> <
    /section>

<!-- end why us section -->

<!-- client section -->

<
section class = "client_section layout_padding" >
    <
    div class = "container" >
    <
    div class = "heading_container heading_center" >
    <
    h2 >
    What Our Customers Say <
    /h2> <
    /div> <
    div class = "carousel-wrap" >
    <
    div class = "owl-carousel" >
    <
    div class = "item" >
    <
    div class = "box" >
    <
    div class = "client_id" >
    <
    div class = "img-box" >
    <
    img src = "images/client-1.jpg"
alt = "" >
    <
    /div> <
    div class = "client_detail" >
    <
    div class = "client_info" >
    <
    h6 >
    Mike Miller <
    /h6> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    /div> <
    i class = "fa fa-quote-left"
aria - hidden = "true" > < /i> <
    /div> <
    /div> <
    div class = "client_text" >
    <
    p >
    Chunks as necessary, making this the first true generator on the Internet.It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum <
    /p> <
    /div> <
    /div> <
    /div> <
    div class = "item" >
    <
    div class = "box" >
    <
    div class = "client_id" >
    <
    div class = "img-box" >
    <
    img src = "images/client-2.jpg"
alt = "" >
    <
    /div> <
    div class = "client_detail" >
    <
    div class = "client_info" >
    <
    h6 >
    Lex William <
    /h6> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    /div> <
    i class = "fa fa-quote-left"
aria - hidden = "true" > < /i> <
    /div> <
    /div> <
    div class = "client_text" >
    <
    p >
    Chunks as necessary, making this the first true generator on the Internet.It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum <
    /p> <
    /div> <
    /div> <
    /div> <
    div class = "item" >
    <
    div class = "box" >
    <
    div class = "client_id" >
    <
    div class = "img-box" >
    <
    img src = "images/client-1.jpg"
alt = "" >
    <
    /div> <
    div class = "client_detail" >
    <
    div class = "client_info" >
    <
    h6 >
    Mike Miller <
    /h6> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    /div> <
    i class = "fa fa-quote-left"
aria - hidden = "true" > < /i> <
    /div> <
    /div> <
    div class = "client_text" >
    <
    p >
    Chunks as necessary, making this the first true generator on the Internet.It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum <
    /p> <
    /div> <
    /div> <
    /div> <
    div class = "item" >
    <
    div class = "box" >
    <
    div class = "client_id" >
    <
    div class = "img-box" >
    <
    img src = "images/client-2.jpg"
alt = "" >
    <
    /div> <
    div class = "client_detail" >
    <
    div class = "client_info" >
    <
    h6 >
    Lex William <
    /h6> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    i class = "fa fa-star"
aria - hidden = "true" > < /i> <
    /div> <
    i class = "fa fa-quote-left"
aria - hidden = "true" > < /i> <
    /div> <
    /div> <
    div class = "client_text" >
    <
    p >
    Chunks as necessary, making this the first true generator on the Internet.It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum <
    /p> <
    /div> <
    /div> <
    /div> <
    /div> <
    /div> <
    /div> <
    /section>

<!-- end client section -->

<!-- contact section -->
<
section class = "contact_section layout_padding"
style = "background-color: white;" >
    <!-- 
    <
    div class = "container" >
    <
    div class = "heading_container heading_center" >
    <
    h2 >
    Contact Us <
    /h2> <
    /div> <
    div class = "row" >
    <
    div class = "col-md-9 mx-auto" >
    <
    div class = "form_container" >
    <
    form >
    <
    div class = "form-row" >
    <
    div class = "form-group col-md-6" >
    <
    input type = "text"
class = "form-control"
placeholder = "First Name" / >
    <
    /div> <
    div class = "form-group col-md-6" >
    <
    input type = "text"
class = "form-control"
placeholder = "Last Name" / >
    <
    /div> <
    /div> <
    div class = "form-row" >
    <
    div class = "form-group col-md-6" >
    <
    input type = "email"
class = "form-control"
placeholder = "Email" / >
    <
    /div> <
    div class = "form-group col-md-6" >
    <
    input type = "text"
class = "form-control"
placeholder = "Phone Number" / >
    <
    /div> <
    /div> <
    div class = "form-group " >
    <
    input type = "text"
class = "message-box"
placeholder = "Message" / >
    <
    /div> <
    div class = "btn-box" >
    <
    button type = "submit" > Submit < /button> <
    /div> <
    /form> <
    /div> <
    /div> <
    /div> <
    /div> -->


<
div class = "grid grid-cols-1 lg:grid-cols-3 md:grid-cols-3 container lg:gap-0 gap-6" >
    <
    div class = "" >
    <
    div class = "bg-[#f5f6f6] lg:w-[400px] lg:pt-4  lg:p-12 lg:h-[200px]  mx-auto text-center" >
    <
    i class = "fa-solid fa-location-dot"
style = "font-size: 80px;" > < /i> <
    p > OUR MAIN OFFICE < /p> <
    p1 > A - 29, Shop No - 2, Sewak Park Exten.Rama Park, Behind Axis Bank, Dwarka Mor, New Delhi - 110059 < /p1> <
    /div> <
    /div> <
    div class = "" >
    <
    div class = "bg-[#f5f6f6] lg:w-[400px] lg:p-12 lg:pt-4 lg:h-[200px] mx-auto items-center text-center" >
    <
    i class = "fa-solid fa-phone"
style = "font-size: 80px;" > < /i> <
    p > PHONE NUMBER < /p> <
    p1 > 9999608716 < /p1> <
    /div> <
    /div> <
    div class = "" >
    <
    div class = "bg-[#f5f6f6] lg:w-[400px] lg:p-12 lg:h-[200px] lg:pt-4  mx-auto text-center" >
    <
    i class = "fa-solid fa-envelope"
style = "font-size: 80px;" > < /i> <
    p > EMAIL < /p> <
    p1 > demo @gmail.com < /p1> <
    /div>

<
/div>

<
/div>



<
div class = "map"
style = "margin-top: 80px;" >
    <
    iframe src = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3502.3114257866173!2d77.03485431549505!3d28.620426991378658!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d05ebc5b55797%3A0x787e5efe0decf9ff!2sAyush%20Laptop%20Repair!5e0!3m2!1sen!2sin!4v1677695321477!5m2!1sen!2sin"
width = "100%"
height = "550"
style = "border:0;"
allowfullscreen = ""
loading = "lazy"
referrerpolicy = "no-referrer-when-downgrade" > < /iframe> <
    /div>

<
/section>
<!-- end contact section -->


<!-- footer section -->
<
footer class = "footer_section" >
    <
    div class = "container" >
    <
    div class = "row" >
    <
    div class = "col-md-6 col-lg-3 footer-col" >
    <
    div class = "footer_detail" >
    <
    h4 >
    About <
    /h4> <
    p >
    Necessary, making this the first true generator on the Internet.It uses a dictionary of over 200 Latin words, combined with a handful <
    /p> <
    div class = "footer_social" >
    <
    a href = "" >
    <
    i class = "fa fa-facebook"
aria - hidden = "true" > < /i> <
    /a> <
    a href = "" >
    <
    i class = "fa fa-twitter"
aria - hidden = "true" > < /i> <
    /a> <
    a href = "" >
    <
    i class = "fa fa-linkedin"
aria - hidden = "true" > < /i> <
    /a> <
    a href = "" >
    <
    i class = "fa fa-instagram"
aria - hidden = "true" > < /i> <
    /a> <
    /div> <
    /div> <
    /div>
    <!-- <div class="col-md-6 col-lg-2 mx-auto footer-col">
    <
    div class = "footer_link_box" >
    <
    h4 >
    Links <
    /h4> <
    div class = "footer_links" >
    <
    a class = "active"
href = "index.html" >
    Home <
    /a> <
    a class = ""
href = "service.html" >
    Services <
    /a> <
    a class = ""
href = "about.html" >
    About <
    /a> <
    a class = ""
href = "why.html" >
    Why Us <
    /a> <
    a class = ""
href = "contact.html" >
    Contact Us <
    /a> <
    /div> <
    /div> <
    /div>
    -->






<
div class = "col-md-6 col-lg-2 mx-auto footer-col" >
    <
    div class = "footer_link_box" >
    <
    h4 >
    Main Menu <
    /h4> <
    div class = "footer_links" >
    <
    a class = "active"
href = "index.html" >
    Home <
    /a> <
    a class = ""
href = "service.html" >
    Apple Repair <
    /a> <
    a class = ""
href = "about.html" >
    Computer Repair <
    /a> <
    a class = ""
href = "why.html" >
    Data Recovery <
    /a> <
    a class = ""
href = "contact.html" >
    Contact Us <
    /a> <
    /div> <
    /div> <
    /div>





<
div class = "col-md-6 col-lg-2 mx-auto footer-col" >
    <
    div class = "footer_link_box" >
    <
    h4 >
    Apple Repair <
    /h4> <
    div class = "footer_links" >
    <
    a class = "active"
href = "index.html" >
    MacBook Repair <
    /a> <
    a class = ""
href = "service.html" >
    MacBook Air Repair <
    /a> <
    a class = ""
href = "about.html" >
    MackBook Pro Repair <
    /a> <
    a class = ""
href = "why.html" >
    iMac Repair <
    /a> <
    a class = ""
href = "contact.html" >
    Mac mini Repair <
    /a> <
    a class = ""
href = "contact.html" >
    Mac Pro Repair <
    /a> <
    a class = ""
href = "contact.html" >
    iPhone Repair <
    /a> <
    /div> <
    /div> <
    /div>



<
div class = "col-md-6 col-lg-2 mx-auto footer-col" >
    <
    div class = "footer_link_box" >
    <
    h4 >
    Computer Repair <
    /h4> <
    div class = "footer_links" >
    <
    a class = "active"
href = "index.html" >
    Laptop Repair <
    /a> <
    a class = ""
href = "service.html" >
    Liquid Damage Repair <
    /a> <
    a class = ""
href = "about.html" >
    Virus Malware Removal <
    /a> <
    a class = ""
href = "why.html" >
    Custom Build Computers <
    /a> <
    a class = ""
href = "contact.html" >
    Windows Repair and Installation <
    /a> <
    a class = ""
href = "contact.html" >
    Mac Pro Repair <
    /a> <
    a class = ""
href = "contact.html" >
    iPhone Repair <
    /a> <
    /div> <
    /div> <
    /div>





<
div class = "col-md-6 col-lg-3 footer-col" >
    <
    div class = "footer_contact" >
    <
    h4 >
    Contact Info <
    /h4> <
    div class = "contact_link_box" >
    <
    p >
    <
    i class = "fa fa-map-marker"
aria - hidden = "true" > < /i> <
    span >
    Location <
    /span> <
    /p> <
    a href = "" >
    <
    i class = "fa fa-phone"
aria - hidden = "true" > < /i> <
    span >
    Call + 01 1234567890 <
    /span> <
    /a> <
    a href = "" >
    <
    i class = "fa fa-envelope"
aria - hidden = "true" > < /i> <
    span >
    demo @gmail.com <
    /span> <
    /a> <
    p >
    <
    i class = "fa fa-clock-o"
aria - hidden = "true" > < /i> <
    span >
    Mon - Sat: 09.00 am - 06.00 pm <
    /span> <
    /p> <
    p >
    <
    i class = "fa fa-clock-o"
aria - hidden = "true" > < /i> <
    span >
    Sunday: closed <
    /span> <
    /p> <
    /div> <
    /div> <
    /div>





<!-- <div class="col-md-6 col-lg-4 footer-col">
<
div class = "map_container" >
    <
    div class = "map" >
    <
    div id = "googleMap" > < /div> <
    /div> <
    /div> <
    /div> --> <
    /div> <
    /div> <
    div class = "footer-info" >
    <
    div class = "container" >
    <
    p >
    &
    copy; < span id = "displayYear" > < /span> All Rights Reserved By <
    a href = "https://html.design/" > AYUSH LAPTOP REPAIR < /a> <
    /p> <
    /div> <
    /div> <
    /footer>
    <!-- footer section -->

<!-- jQery -->
<
script src = "js/jquery-3.4.1.min.js" > < /script>
    <!-- bootstrap js -->
    <
    script src = "js/bootstrap.js" > < /script> <
    script src = "https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" >
    <
    /script>
    <!-- custom js -->
    <
    script src = "js/custom.js" > < /script>
    <!-- Google Map -->
    <
    script src = "https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap" >
    <
    /script>
    <!-- End Google Map -->



<
script src = "js/script.js" > < /script> <
    script >
    function myFunction() {
        var dots = document.getElementById("dots");
        var moreText = document.getElementById("more");
        var btnText = document.getElementById("myBtn");

        if (dots.style.display === "none") {
            dots.style.display = "inline";
            btnText.innerHTML = "Read more";
            moreText.style.display = "none";
        } else {
            dots.style.display = "none";
            btnText.innerHTML = "Read less";
            moreText.style.display = "inline";
        }
    }



function myFunctions() {
    var dotss = document.getElementById("dotss");
    var moreTexts = document.getElementById("mores");
    var btnTexts = document.getElementById("myBtns");

    if (dotss.style.display === "none") {
        dotss.style.display = "inline";
        btnTexts.innerHTML = "Read more";
        moreTexts.style.display = "none";
    } else {
        dotss.style.display = "none";
        btnTexts.innerHTML = "Read less";
        moreTexts.style.display = "inline";
    }
}




function myFunctionss() {
    var dotsss = document.getElementById("dotsss");
    var moreTextss = document.getElementById("moress");
    var btnTextss = document.getElementById("myBtns");

    if (dotsss.style.display === "none") {
        dotsss.style.display = "inline";
        btnTextss.innerHTML = "Read more";
        moreTextss.style.display = "none";
    } else {
        dotsss.style.display = "none";
        btnTextss.innerHTML = "Read less";
        moreTextss.style.display = "inline";
    }
} <
/script>

<!-- <script src="script.js">
function myFunction() {
    var dots = document.getElementById("dots");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("myBtn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.innerHTML = "Read less";
        moreText.style.display = "inline";
    }
}





<
/script> --> <
/body>

<
/html>